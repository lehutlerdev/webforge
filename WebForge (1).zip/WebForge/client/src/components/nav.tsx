import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export function Nav() {
  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <a className="text-xl font-bold font-heading text-primary">WebStart</a>
          </Link>
        </div>
        
        <div className="hidden md:flex gap-6">
          <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">Services</a>
          <a href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">Tarifs</a>
          <a href="#contact" className="text-sm font-medium hover:text-primary transition-colors">Contact</a>
        </div>

        <div>
          <Button variant="default" size="sm" asChild>
            <a href="#contact">Commencer</a>
          </Button>
        </div>
      </div>
    </nav>
  );
}