import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import heroImage from "@assets/generated_images/modern_web_design_abstract_hero_illustration.png";

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-background pt-16 pb-32">
      <div className="container relative z-10">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl font-bold tracking-tight sm:text-6xl text-foreground font-heading">
              Votre site web professionnel à <span className="text-primary">petit prix</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-[600px]">
              Nous créons des sites web modernes, rapides et optimisés pour votre entreprise. 
              Une présence en ligne de qualité ne devrait pas coûter une fortune.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="gap-2" asChild>
                <a href="#pricing">
                  Voir nos offres <ArrowRight className="w-4 h-4" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#features">En savoir plus</a>
              </Button>
            </div>
            
            <div className="pt-8 flex items-center gap-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>Livraison rapide</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>Support inclus</span>
              </div>
            </div>
          </div>
          
          <div className="relative lg:ml-auto">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50">
               <img 
                src={heroImage} 
                alt="Web Design Abstract" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 to-transparent pointer-events-none" />
            </div>
            {/* Decorative elements */}
            <div className="absolute -z-10 -top-12 -right-12 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
            <div className="absolute -z-10 -bottom-12 -left-12 w-64 h-64 bg-secondary/10 rounded-full blur-3xl" />
          </div>
        </div>
      </div>
    </div>
  );
}