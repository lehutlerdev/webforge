export function Footer() {
  return (
    <footer className="bg-background border-t py-12">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold font-heading text-primary">WebStart</span>
          </div>
          
          <p className="text-sm text-muted-foreground text-center md:text-right">
            © {new Date().getFullYear()} WebStart. Tous droits réservés. <br />
            <span className="text-xs">Fait avec ❤️ pour les entrepreneurs.</span>
          </p>
        </div>
      </div>
    </footer>
  );
}