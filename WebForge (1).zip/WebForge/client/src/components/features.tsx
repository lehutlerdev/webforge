import { Layout, Smartphone, Search, Zap, Shield, Rocket } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const features = [
  {
    icon: Layout,
    title: "Design Moderne",
    description: "Des interfaces épurées et professionnelles qui mettent en valeur votre marque."
  },
  {
    icon: Smartphone,
    title: "100% Responsive",
    description: "Votre site s'adapte parfaitement à tous les écrans : mobile, tablette et ordinateur."
  },
  {
    icon: Search,
    title: "Optimisé SEO",
    description: "Structure optimisée pour que vos clients vous trouvent facilement sur Google."
  },
  {
    icon: Zap,
    title: "Performance Rapide",
    description: "Temps de chargement ultra-rapides pour ne perdre aucun visiteur."
  },
  {
    icon: Shield,
    title: "Sécurisé",
    description: "Protection HTTPS incluse et bonnes pratiques de sécurité respectées."
  },
  {
    icon: Rocket,
    title: "Livraison Express",
    description: "Votre site en ligne en quelques jours, pas en quelques mois."
  }
];

export function Features() {
  return (
    <section id="features" className="py-24 bg-muted/30">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl font-bold font-heading sm:text-4xl">Tout ce dont vous avez besoin</h2>
          <p className="text-muted-foreground text-lg">
            Nous ne faisons pas de compromis sur la qualité. Chaque site inclut les essentiels pour réussir en ligne.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-none shadow-sm hover:shadow-md transition-shadow duration-300">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 text-primary">
                  <feature.icon className="w-6 h-6" />
                </div>
                <CardTitle className="text-xl font-heading">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}