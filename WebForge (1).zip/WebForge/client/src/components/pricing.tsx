import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const plans = [
  {
    name: "Vitrine",
    price: "499€",
    description: "Idéal pour présenter votre activité simplement.",
    features: [
      "Site One-Page (Page unique)",
      "Design Responsive",
      "Formulaire de contact",
      "Intégration réseaux sociaux",
      "Hébergement inclus (1 an)",
      "Nom de domaine offert (1 an)"
    ]
  },
  {
    name: "Business",
    price: "899€",
    description: "Pour les entreprises qui veulent convaincre.",
    popular: true,
    features: [
      "Site Multi-pages (jusqu'à 5)",
      "Design Sur-mesure",
      "Optimisation SEO avancée",
      "Blog / Actualités",
      "Google Analytics",
      "Formation prise en main",
      "Support prioritaire"
    ]
  },
  {
    name: "E-Commerce",
    price: "1499€",
    description: "Vendez vos produits en ligne efficacement.",
    features: [
      "Boutique en ligne complète",
      "Jusqu'à 50 produits",
      "Paiement sécurisé (Stripe/Paypal)",
      "Gestion des stocks",
      "Compte client",
      "Facturation automatique",
      "Formation administration"
    ]
  }
];

export function Pricing() {
  return (
    <section id="pricing" className="py-24 container">
      <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
        <h2 className="text-3xl font-bold font-heading sm:text-4xl">Tarifs Transparents</h2>
        <p className="text-muted-foreground text-lg">
          Pas de coûts cachés. Choisissez l'offre qui correspond à vos besoins et à votre budget.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan, index) => (
          <Card 
            key={index} 
            className={`flex flex-col relative ${plan.popular ? 'border-primary shadow-lg scale-105 z-10' : 'border-border shadow-sm'}`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                Le plus populaire
              </div>
            )}
            <CardHeader>
              <CardTitle className="text-2xl font-heading">{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className="text-muted-foreground text-sm"> /ttc</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <Check className="w-5 h-5 text-primary shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant={plan.popular ? "default" : "outline"} asChild>
                <a href="#contact">Choisir cette offre</a>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  );
}